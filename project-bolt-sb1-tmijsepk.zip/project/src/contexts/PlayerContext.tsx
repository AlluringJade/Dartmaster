import React, { createContext, useContext, useState, useEffect } from 'react';
import { Player } from '../types';

// Sample initial players
const initialPlayers: Player[] = [
  {
    id: '1',
    name: 'Player 1',
    avatar: 'https://i.pravatar.cc/150?img=1',
    stats: {
      gamesPlayed: 0,
      gamesWon: 0,
      averageScore: 0,
      highestScore: 0,
      tournaments: [],
    },
  },
  {
    id: '2',
    name: 'Player 2',
    avatar: 'https://i.pravatar.cc/150?img=2',
    stats: {
      gamesPlayed: 0,
      gamesWon: 0,
      averageScore: 0,
      highestScore: 0,
      tournaments: [],
    },
  },
];

interface PlayerContextType {
  players: Player[];
  addPlayer: (player: Omit<Player, 'id'>) => void;
  updatePlayer: (id: string, updates: Partial<Player>) => void;
  removePlayer: (id: string) => void;
  getPlayer: (id: string) => Player | undefined;
  selectedPlayers: Player[];
  selectPlayer: (id: string) => void;
  deselectPlayer: (id: string) => void;
  clearSelectedPlayers: () => void;
}

const PlayerContext = createContext<PlayerContextType | undefined>(undefined);

export const PlayerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [players, setPlayers] = useState<Player[]>(initialPlayers);
  const [selectedPlayers, setSelectedPlayers] = useState<Player[]>([]);

  // Load players from localStorage on initial render
  useEffect(() => {
    const savedPlayers = localStorage.getItem('dartPlayers');
    if (savedPlayers) {
      setPlayers(JSON.parse(savedPlayers));
    }
  }, []);

  // Save players to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('dartPlayers', JSON.stringify(players));
  }, [players]);

  const addPlayer = (player: Omit<Player, 'id'>) => {
    const newPlayer: Player = {
      ...player,
      id: Date.now().toString(),
      stats: {
        gamesPlayed: 0,
        gamesWon: 0,
        averageScore: 0,
        highestScore: 0,
        tournaments: [],
      },
    };
    setPlayers((prev) => [...prev, newPlayer]);
  };

  const updatePlayer = (id: string, updates: Partial<Player>) => {
    setPlayers((prev) =>
      prev.map((player) => (player.id === id ? { ...player, ...updates } : player))
    );
  };

  const removePlayer = (id: string) => {
    setPlayers((prev) => prev.filter((player) => player.id !== id));
    setSelectedPlayers((prev) => prev.filter((player) => player.id !== id));
  };

  const getPlayer = (id: string) => {
    return players.find((player) => player.id === id);
  };

  const selectPlayer = (id: string) => {
    const player = getPlayer(id);
    if (player && !selectedPlayers.find((p) => p.id === id)) {
      setSelectedPlayers((prev) => [...prev, player]);
    }
  };

  const deselectPlayer = (id: string) => {
    setSelectedPlayers((prev) => prev.filter((player) => player.id !== id));
  };

  const clearSelectedPlayers = () => {
    setSelectedPlayers([]);
  };

  return (
    <PlayerContext.Provider
      value={{
        players,
        addPlayer,
        updatePlayer,
        removePlayer,
        getPlayer,
        selectedPlayers,
        selectPlayer,
        deselectPlayer,
        clearSelectedPlayers,
      }}
    >
      {children}
    </PlayerContext.Provider>
  );
};

export const usePlayers = () => {
  const context = useContext(PlayerContext);
  if (context === undefined) {
    throw new Error('usePlayers must be used within a PlayerProvider');
  }
  return context;
};