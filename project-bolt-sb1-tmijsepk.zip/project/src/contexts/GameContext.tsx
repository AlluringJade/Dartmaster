import React, { createContext, useContext, useState, useReducer } from 'react';
import { GameState, GameAction, Player } from '../types';

// Initial state for the game context
const initialState: GameState = {
  gameType: null,
  players: [],
  currentPlayerIndex: 0,
  scores: {},
  history: [],
  isGameActive: false,
  winner: null,
  roundNumber: 1,
};

// Reducer function to handle game state changes
function gameReducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case 'START_GAME':
      return {
        ...state,
        gameType: action.payload.gameType,
        players: action.payload.players,
        scores: action.payload.players.reduce((acc, player) => {
          acc[player.id] = action.payload.gameType === '501' ? 501 : 0;
          return acc;
        }, {} as Record<string, number>),
        isGameActive: true,
        winner: null,
        roundNumber: 1,
        history: [],
        currentPlayerIndex: 0,
      };
    case 'RECORD_SCORE':
      const { playerId, score } = action.payload;
      const newScores = { ...state.scores };
      
      if (state.gameType === '501') {
        newScores[playerId] = Math.max(0, newScores[playerId] - score);
      } else {
        // For other game types like cricket
        newScores[playerId] = newScores[playerId] + score;
      }
      
      return {
        ...state,
        scores: newScores,
        history: [...state.history, {
          playerId,
          score,
          roundNumber: state.roundNumber,
          timestamp: new Date().toISOString()
        }]
      };
    case 'NEXT_PLAYER':
      const nextPlayerIndex = (state.currentPlayerIndex + 1) % state.players.length;
      const newRoundNumber = nextPlayerIndex === 0 ? state.roundNumber + 1 : state.roundNumber;
      
      return {
        ...state,
        currentPlayerIndex: nextPlayerIndex,
        roundNumber: newRoundNumber,
      };
    case 'END_GAME':
      return {
        ...state,
        isGameActive: false,
        winner: action.payload.winnerId,
      };
    case 'RESET_GAME':
      return initialState;
    default:
      return state;
  }
}

// Create the context
type GameContextType = {
  state: GameState;
  dispatch: React.Dispatch<GameAction>;
};

const GameContext = createContext<GameContextType | undefined>(undefined);

// Provider component
export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(gameReducer, initialState);

  return (
    <GameContext.Provider value={{ state, dispatch }}>
      {children}
    </GameContext.Provider>
  );
};

// Custom hook to use the game context
export const useGame = () => {
  const context = useContext(GameContext);
  if (context === undefined) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};