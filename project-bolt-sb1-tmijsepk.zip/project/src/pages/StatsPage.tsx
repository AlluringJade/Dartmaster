import React, { useState } from 'react';
import { usePlayers } from '../contexts/PlayerContext';
import { BarChart, PieChart, Activity, TrendingUp, CircleDot } from 'lucide-react';

const StatsPage: React.FC = () => {
  const { players } = usePlayers();
  const [selectedPlayerId, setSelectedPlayerId] = useState<string | null>(null);
  
  const selectedPlayer = selectedPlayerId 
    ? players.find(p => p.id === selectedPlayerId) 
    : null;
  
  // Generate some mock stats data for visualization
  const generateMockData = (playerId: string) => {
    const seed = playerId.charCodeAt(0) + playerId.length;
    
    // Last 7 games average scores
    const gameScores = Array.from({ length: 7 }, (_, i) => ({
      game: i + 1,
      score: Math.floor(30 + (seed % 10) * 3 + Math.random() * 15)
    }));
    
    // Hit accuracy by section
    const sections = ['Singles', 'Doubles', 'Triples', 'Bull'];
    const accuracy = sections.map(section => ({
      section,
      accuracy: Math.floor(40 + (seed % 20) + Math.random() * 30)
    }));
    
    // Most hit numbers
    const numbers = [20, 19, 18, 17, 16, 15, 'Bull'];
    const hitFrequency = numbers.map(num => ({
      number: num,
      hits: Math.floor(10 + (seed % 10) * 2 + Math.random() * 20)
    })).sort((a, b) => b.hits - a.hits);
    
    return {
      gameScores,
      accuracy,
      hitFrequency
    };
  };
  
  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Statistics</h1>
      
      {/* Player selection */}
      <div className="bg-white rounded-xl shadow-md p-6 mb-6">
        <h2 className="font-semibold text-gray-800 mb-4">Select Player</h2>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {players.map(player => (
            <div
              key={player.id}
              onClick={() => setSelectedPlayerId(player.id)}
              className={`p-4 rounded-lg text-center cursor-pointer transition-all ${
                selectedPlayerId === player.id
                  ? 'bg-emerald-100 border-2 border-emerald-500'
                  : 'bg-gray-50 hover:bg-gray-100 border-2 border-transparent'
              }`}
            >
              <img
                src={player.avatar}
                alt={player.name}
                className="w-16 h-16 object-cover rounded-full mx-auto mb-2"
              />
              <div className="font-medium text-gray-800">{player.name}</div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Stats display */}
      {selectedPlayer ? (
        <div className="space-y-6">
          {/* Summary stats */}
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="px-6 py-4 border-b">
              <h2 className="font-semibold text-gray-800">
                {selectedPlayer.name}'s Statistics
              </h2>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-y md:divide-y-0 divide-gray-100">
              <div className="p-6 text-center">
                <div className="text-3xl font-bold text-emerald-600">
                  {selectedPlayer.stats.gamesPlayed}
                </div>
                <div className="text-sm text-gray-500 mt-1">Games Played</div>
              </div>
              <div className="p-6 text-center">
                <div className="text-3xl font-bold text-emerald-600">
                  {selectedPlayer.stats.gamesWon}
                </div>
                <div className="text-sm text-gray-500 mt-1">Games Won</div>
              </div>
              <div className="p-6 text-center">
                <div className="text-3xl font-bold text-emerald-600">
                  {selectedPlayer.stats.averageScore}
                </div>
                <div className="text-sm text-gray-500 mt-1">Average Score</div>
              </div>
              <div className="p-6 text-center">
                <div className="text-3xl font-bold text-emerald-600">
                  {selectedPlayer.stats.highestScore}
                </div>
                <div className="text-sm text-gray-500 mt-1">Highest Score</div>
              </div>
            </div>
          </div>
          
          {/* Performance charts */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Game Performance */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <div className="flex items-center mb-4">
                <Activity size={20} className="text-blue-600 mr-2" />
                <h3 className="font-semibold text-gray-800">Recent Games</h3>
              </div>
              
              <div className="h-64 flex items-end justify-between space-x-2">
                {generateMockData(selectedPlayer.id).gameScores.map((game, i) => (
                  <div key={i} className="flex flex-col items-center flex-1">
                    <div 
                      className="w-full bg-blue-500 rounded-t-sm" 
                      style={{ 
                        height: `${game.score * 2}px`,
                        maxHeight: '180px',
                      }}
                    ></div>
                    <div className="text-xs text-gray-500 mt-1">Game {game.game}</div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Hit Accuracy */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <div className="flex items-center mb-4">
                <TrendingUp size={20} className="text-purple-600 mr-2" />
                <h3 className="font-semibold text-gray-800">Hit Accuracy</h3>
              </div>
              
              <div className="space-y-4">
                {generateMockData(selectedPlayer.id).accuracy.map((item, i) => (
                  <div key={i}>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm text-gray-600">{item.section}</span>
                      <span className="text-sm font-medium text-gray-800">{item.accuracy}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div 
                        className="bg-purple-600 h-2.5 rounded-full" 
                        style={{ width: `${item.accuracy}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          {/* Most hit numbers */}
          <div className="bg-white rounded-xl shadow-md p-6">
            <div className="flex items-center mb-4">
              <CircleDot size={20} className="text-amber-600 mr-2" />
              <h3 className="font-semibold text-gray-800">Most Hit Numbers</h3>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
              {generateMockData(selectedPlayer.id).hitFrequency.map((item, i) => (
                <div key={i} className="text-center">
                  <div className={`w-16 h-16 mx-auto rounded-full flex items-center justify-center text-white font-bold text-lg ${
                    i === 0 ? 'bg-amber-500' : 
                    i === 1 ? 'bg-amber-400' : 
                    i === 2 ? 'bg-amber-300' : 'bg-gray-400'
                  }`}>
                    {item.number}
                  </div>
                  <div className="mt-2 text-sm text-gray-600">{item.hits} hits</div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Tournament History */}
          {selectedPlayer.stats.tournaments.length > 0 ? (
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="px-6 py-4 border-b">
                <h3 className="font-semibold text-gray-800">Tournament History</h3>
              </div>
              
              <div className="divide-y divide-gray-100">
                {selectedPlayer.stats.tournaments.map((tournament, i) => (
                  <div key={i} className="px-6 py-4 flex justify-between items-center">
                    <div>
                      <div className="font-medium text-gray-800">{tournament.name}</div>
                      <div className="text-sm text-gray-500">
                        {new Date(tournament.date).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-sm">
                      {tournament.position === 1 
                        ? '1st Place' 
                        : tournament.position === 2 
                          ? '2nd Place' 
                          : tournament.position === 3 
                            ? '3rd Place' 
                            : `${tournament.position}th Place`}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-md p-6 text-center">
              <div className="mb-2 text-gray-500">No tournament history yet</div>
            </div>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-md p-8 text-center">
          <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
            <BarChart size={32} className="text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-800 mb-2">No Player Selected</h3>
          <p className="text-gray-600">
            Select a player above to view their statistics
          </p>
        </div>
      )}
    </div>
  );
};

export default StatsPage;