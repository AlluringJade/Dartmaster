import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft, Target, Award, Camera, Save } from 'lucide-react';
import { usePlayers } from '../contexts/PlayerContext';
import { useGame } from '../contexts/GameContext';
import { GameType } from '../types';
import ScoreInput from '../components/game/ScoreInput';
import GameScoreboard from '../components/game/GameScoreboard';
import PlayerSelection from '../components/game/PlayerSelection';

const GamePage: React.FC = () => {
  const { gameType } = useParams<{ gameType: string }>();
  const navigate = useNavigate();
  const { players, selectedPlayers, clearSelectedPlayers } = usePlayers();
  const { state, dispatch } = useGame();
  const [showPlayerSelection, setShowPlayerSelection] = useState(!state.isGameActive);
  const [isUsingCamera, setIsUsingCamera] = useState(false);

  // Validate game type
  useEffect(() => {
    const validGameTypes = ['501', 'cricket', 'around-the-clock'];
    if (gameType && !validGameTypes.includes(gameType)) {
      navigate('/');
    }
  }, [gameType, navigate]);

  // Start new game when players are selected
  const startGame = () => {
    if (selectedPlayers.length >= 1) {
      dispatch({
        type: 'START_GAME',
        payload: {
          gameType: gameType as GameType,
          players: selectedPlayers,
        },
      });
      setShowPlayerSelection(false);
    }
  };

  // Handle score submission
  const handleScoreSubmit = (score: number) => {
    const currentPlayer = state.players[state.currentPlayerIndex];
    
    // Record the score
    dispatch({
      type: 'RECORD_SCORE',
      payload: {
        playerId: currentPlayer.id,
        score,
      },
    });
    
    // Check for winner in 501
    if (gameType === '501' && state.scores[currentPlayer.id] === 0) {
      dispatch({
        type: 'END_GAME',
        payload: {
          winnerId: currentPlayer.id,
        },
      });
      return;
    }
    
    // Move to next player
    dispatch({ type: 'NEXT_PLAYER' });
  };

  // Reset game
  const resetGame = () => {
    dispatch({ type: 'RESET_GAME' });
    clearSelectedPlayers();
    setShowPlayerSelection(true);
  };

  const getGameTitle = () => {
    switch (gameType) {
      case '501':
        return '501';
      case 'cricket':
        return 'Cricket';
      case 'around-the-clock':
        return 'Around the Clock';
      default:
        return 'Game';
    }
  };

  // Render player selection screen
  if (showPlayerSelection) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center mb-6">
          <button 
            onClick={() => navigate('/')}
            className="mr-4 p-2 rounded-full hover:bg-gray-100"
          >
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-2xl font-bold text-gray-800">{getGameTitle()}</h1>
        </div>
        
        <PlayerSelection onStartGame={startGame} />
      </div>
    );
  }

  // Render game screen
  return (
    <div className="max-w-4xl mx-auto">
      {/* Game Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <div className="flex items-center mb-4 sm:mb-0">
          <button 
            onClick={resetGame}
            className="mr-4 p-2 rounded-full hover:bg-gray-100"
          >
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-2xl font-bold text-gray-800">{getGameTitle()}</h1>
          {state.winner && (
            <div className="ml-4 inline-flex items-center px-3 py-1 bg-amber-100 text-amber-800 rounded-full">
              <Award size={16} className="mr-1" />
              <span>Game Complete</span>
            </div>
          )}
        </div>
        
        <div className="flex space-x-2">
          <button 
            onClick={() => setIsUsingCamera(!isUsingCamera)}
            className={`p-2 rounded-md flex items-center ${
              isUsingCamera 
                ? 'bg-purple-100 text-purple-700' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <Camera size={20} className="mr-1" />
            <span>Camera</span>
          </button>
          
          <button 
            onClick={resetGame}
            className="p-2 rounded-md bg-gray-100 text-gray-700 hover:bg-gray-200 flex items-center"
          >
            <Save size={20} className="mr-1" />
            <span>Save Game</span>
          </button>
        </div>
      </div>
      
      {/* Game Content */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Scoreboard */}
        <div className="lg:col-span-8">
          <GameScoreboard />
        </div>
        
        {/* Score Input */}
        <div className="lg:col-span-4">
          {!state.winner && (
            <ScoreInput 
              gameType={gameType as GameType} 
              isUsingCamera={isUsingCamera}
              onScoreSubmit={handleScoreSubmit} 
            />
          )}
          
          {state.winner && (
            <div className="bg-white rounded-xl shadow-md p-6 text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-amber-100 rounded-full flex items-center justify-center">
                <Award size={32} className="text-amber-600" />
              </div>
              <h2 className="text-xl font-bold mb-2">Game Complete!</h2>
              <p className="text-gray-600 mb-4">
                {state.players.find(p => p.id === state.winner)?.name} has won the game!
              </p>
              <div className="flex justify-center space-x-4">
                <button
                  onClick={resetGame}
                  className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 transition-colors"
                >
                  New Game
                </button>
                <button
                  onClick={() => navigate('/stats')}
                  className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
                >
                  View Stats
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GamePage;