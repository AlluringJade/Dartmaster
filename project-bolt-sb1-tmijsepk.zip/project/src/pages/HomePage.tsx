import React from 'react';
import { Link } from 'react-router-dom';
import { Target, Trophy, Users, Monitor, Camera, Database } from 'lucide-react';
import { usePlayers } from '../contexts/PlayerContext';

const HomePage: React.FC = () => {
  const { players } = usePlayers();

  const gameTypes = [
    {
      type: '501',
      title: '501',
      description: 'Classic 501 countdown game. First to zero wins!',
      icon: <Target size={32} className="text-emerald-600" />,
      path: '/game/501',
    },
    {
      type: 'cricket',
      title: 'Cricket',
      description: 'Close numbers 15-20 and bullseye to win!',
      icon: <Target size={32} className="text-blue-600" />,
      path: '/game/cricket',
    },
    {
      type: 'around-the-clock',
      title: 'Around the Clock',
      description: 'Hit numbers 1-20 in sequence. Race against time!',
      icon: <Target size={32} className="text-purple-600" />,
      path: '/game/around-the-clock',
    },
  ];

  const features = [
    {
      title: 'Play with Friends',
      description: 'Add players and compete in real-time',
      icon: <Users size={32} className="text-emerald-600" />,
    },
    {
      title: 'Tournament Mode',
      description: 'Create and manage tournament brackets',
      icon: <Trophy size={32} className="text-amber-600" />,
    },
    {
      title: 'Play vs Computer',
      description: 'Practice against AI opponents of varying skill',
      icon: <Monitor size={32} className="text-blue-600" />,
    },
    {
      title: 'Camera Scoring',
      description: 'Use your camera to automatically track scores',
      icon: <Camera size={32} className="text-purple-600" />,
    },
    {
      title: 'Detailed Statistics',
      description: 'Track your improvement with comprehensive stats',
      icon: <Database size={32} className="text-pink-600" />,
    },
  ];

  return (
    <div className="space-y-10">
      {/* Hero section */}
      <section className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-emerald-600 to-emerald-800 text-white p-8 md:p-12">
        <div className="absolute inset-0 opacity-10">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path
              d="M0,0 L100,0 L100,100 L0,100 Z"
              fill="none"
              stroke="currentColor"
              strokeWidth="4"
              strokeDasharray="8,8"
            />
          </svg>
        </div>
        <div className="relative z-10 max-w-3xl mx-auto text-center">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">
            Welcome to DartMaster
          </h1>
          <p className="text-lg md:text-xl opacity-90 mb-8">
            The ultimate companion for dart players. Track scores, organize tournaments, and improve your game.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link
              to="/game/501"
              className="px-6 py-3 bg-white text-emerald-700 font-medium rounded-lg shadow-md hover:bg-gray-100 transition-colors"
            >
              Start Playing
            </Link>
            <Link
              to="/tournament"
              className="px-6 py-3 bg-emerald-700 text-white font-medium rounded-lg shadow-md hover:bg-emerald-800 transition-colors"
            >
              Create Tournament
            </Link>
          </div>
        </div>
      </section>

      {/* Game modes */}
      <section>
        <h2 className="text-2xl font-bold mb-6 text-gray-800">Game Modes</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {gameTypes.map((game) => (
            <Link
              key={game.type}
              to={game.path}
              className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow p-6 border border-gray-100"
            >
              <div className="flex flex-col items-center text-center">
                <div className="mb-4 p-3 bg-gray-50 rounded-full">{game.icon}</div>
                <h3 className="text-xl font-semibold mb-2 text-gray-800">{game.title}</h3>
                <p className="text-gray-600">{game.description}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Features */}
      <section>
        <h2 className="text-2xl font-bold mb-6 text-gray-800">Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow p-6 border border-gray-100"
            >
              <div className="flex items-start">
                <div className="mr-4">{feature.icon}</div>
                <div>
                  <h3 className="text-lg font-semibold mb-2 text-gray-800">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Recent players */}
      <section>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Players</h2>
          <Link 
            to="/profile" 
            className="text-emerald-600 hover:text-emerald-700 font-medium"
          >
            Manage Players
          </Link>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {players.map((player) => (
            <div 
              key={player.id}
              className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow p-4 text-center"
            >
              <img 
                src={player.avatar} 
                alt={player.name} 
                className="w-16 h-16 object-cover rounded-full mx-auto mb-3"
              />
              <h3 className="font-medium text-gray-800">{player.name}</h3>
              <p className="text-sm text-gray-500">
                {player.stats.gamesPlayed} games played
              </p>
            </div>
          ))}
          <Link
            to="/profile"
            className="flex flex-col items-center justify-center bg-gray-50 rounded-xl border border-dashed border-gray-300 p-4 hover:bg-gray-100 transition-colors"
          >
            <div className="w-16 h-16 flex items-center justify-center rounded-full bg-gray-100 mb-3">
              <Users size={24} className="text-gray-500" />
            </div>
            <span className="font-medium text-gray-600">Add Player</span>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;