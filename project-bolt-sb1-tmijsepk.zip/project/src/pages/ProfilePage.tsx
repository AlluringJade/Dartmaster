import React, { useState } from 'react';
import { usePlayers } from '../contexts/PlayerContext';
import { Pencil, Trash2, UserPlus, Save, X } from 'lucide-react';

const ProfilePage: React.FC = () => {
  const { players, addPlayer, updatePlayer, removePlayer } = usePlayers();
  const [isAddingPlayer, setIsAddingPlayer] = useState(false);
  const [editingPlayerId, setEditingPlayerId] = useState<string | null>(null);
  const [newPlayer, setNewPlayer] = useState({
    name: '',
    avatar: 'https://i.pravatar.cc/150?img=3',
  });
  const [editingPlayer, setEditingPlayer] = useState({
    id: '',
    name: '',
    avatar: '',
  });

  // Handle adding a new player
  const handleAddPlayer = () => {
    if (newPlayer.name.trim()) {
      addPlayer({
        name: newPlayer.name,
        avatar: newPlayer.avatar || `https://i.pravatar.cc/150?img=${Math.floor(Math.random() * 70)}`,
        stats: {
          gamesPlayed: 0,
          gamesWon: 0,
          averageScore: 0,
          highestScore: 0,
          tournaments: [],
        },
      });
      setNewPlayer({
        name: '',
        avatar: 'https://i.pravatar.cc/150?img=3',
      });
      setIsAddingPlayer(false);
    }
  };

  // Start editing a player
  const startEditing = (player: any) => {
    setEditingPlayerId(player.id);
    setEditingPlayer({
      id: player.id,
      name: player.name,
      avatar: player.avatar,
    });
  };

  // Save player edits
  const saveEdits = () => {
    if (editingPlayer.name.trim()) {
      updatePlayer(editingPlayer.id, {
        name: editingPlayer.name,
        avatar: editingPlayer.avatar,
      });
      setEditingPlayerId(null);
    }
  };

  // Cancel editing
  const cancelEditing = () => {
    setEditingPlayerId(null);
  };

  // Delete a player
  const handleDeletePlayer = (id: string) => {
    if (confirm('Are you sure you want to delete this player?')) {
      removePlayer(id);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Player Profiles</h1>
        <button
          onClick={() => setIsAddingPlayer(!isAddingPlayer)}
          className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 flex items-center"
        >
          <UserPlus size={18} className="mr-2" />
          <span>Add Player</span>
        </button>
      </div>

      {/* Add Player Form */}
      {isAddingPlayer && (
        <div className="bg-white rounded-xl shadow-md p-6 mb-6">
          <h2 className="font-semibold text-lg mb-4">Add New Player</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Name
              </label>
              <input
                type="text"
                value={newPlayer.name}
                onChange={(e) => setNewPlayer({ ...newPlayer, name: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                placeholder="Enter player name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Avatar URL
              </label>
              <input
                type="text"
                value={newPlayer.avatar}
                onChange={(e) => setNewPlayer({ ...newPlayer, avatar: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                placeholder="https://example.com/avatar.jpg"
              />
            </div>
          </div>
          <div className="flex justify-end mt-4 space-x-2">
            <button
              onClick={() => setIsAddingPlayer(false)}
              className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={handleAddPlayer}
              disabled={!newPlayer.name.trim()}
              className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 disabled:opacity-50"
            >
              Add Player
            </button>
          </div>
        </div>
      )}

      {/* Player List */}
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="px-6 py-4 border-b">
          <h2 className="font-semibold text-gray-800">Your Players</h2>
        </div>
        
        {players.length > 0 ? (
          <div className="divide-y divide-gray-100">
            {players.map((player) => (
              <div key={player.id} className="px-6 py-4">
                {editingPlayerId === player.id ? (
                  <div className="flex flex-col md:flex-row md:items-center">
                    <div className="flex-shrink-0 mb-4 md:mb-0 md:mr-4">
                      <img
                        src={editingPlayer.avatar}
                        alt={editingPlayer.name}
                        className="w-16 h-16 rounded-full object-cover"
                      />
                    </div>
                    <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Name
                        </label>
                        <input
                          type="text"
                          value={editingPlayer.name}
                          onChange={(e) =>
                            setEditingPlayer({ ...editingPlayer, name: e.target.value })
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-md"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Avatar URL
                        </label>
                        <input
                          type="text"
                          value={editingPlayer.avatar}
                          onChange={(e) =>
                            setEditingPlayer({ ...editingPlayer, avatar: e.target.value })
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-md"
                        />
                      </div>
                    </div>
                    <div className="flex justify-end space-x-2 mt-4 md:mt-0 md:ml-4">
                      <button
                        onClick={cancelEditing}
                        className="p-2 rounded-full text-gray-500 hover:text-gray-700 hover:bg-gray-100"
                      >
                        <X size={20} />
                      </button>
                      <button
                        onClick={saveEdits}
                        className="p-2 rounded-full text-green-500 hover:text-green-700 hover:bg-green-100"
                      >
                        <Save size={20} />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <img
                        src={player.avatar}
                        alt={player.name}
                        className="w-16 h-16 rounded-full object-cover"
                      />
                    </div>
                    <div className="ml-4 flex-1">
                      <h3 className="text-lg font-medium text-gray-800">{player.name}</h3>
                      <div className="flex space-x-4 text-sm text-gray-500 mt-1">
                        <span>{player.stats.gamesPlayed} Games</span>
                        <span>{player.stats.gamesWon} Wins</span>
                        <span>Avg: {player.stats.averageScore}</span>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => startEditing(player)}
                        className="p-2 rounded-full text-blue-500 hover:text-blue-700 hover:bg-blue-100"
                      >
                        <Pencil size={18} />
                      </button>
                      <button
                        onClick={() => handleDeletePlayer(player.id)}
                        className="p-2 rounded-full text-red-500 hover:text-red-700 hover:bg-red-100"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="p-6 text-center">
            <p className="text-gray-500">No players found. Add some players to get started!</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfilePage;