import React, { useState } from 'react';
import { usePlayers } from '../contexts/PlayerContext';
import { Trophy, Calendar, Users, Plus, X } from 'lucide-react';
import { Tournament } from '../types';

const TournamentPage: React.FC = () => {
  const { players, selectedPlayers, selectPlayer, deselectPlayer, clearSelectedPlayers } = usePlayers();
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [newTournament, setNewTournament] = useState({
    name: '',
    date: new Date().toISOString().split('T')[0],
  });
  const [activeTournament, setActiveTournament] = useState<Tournament | null>(null);

  // Create a new tournament
  const createTournament = () => {
    if (newTournament.name && selectedPlayers.length >= 2) {
      // Generate tournament brackets
      const matches = generateMatches(selectedPlayers);
      
      const tournament: Tournament = {
        id: Date.now().toString(),
        name: newTournament.name,
        date: newTournament.date,
        players: [...selectedPlayers],
        matches,
        winner: null,
        isComplete: false,
      };
      
      setTournaments([...tournaments, tournament]);
      setNewTournament({
        name: '',
        date: new Date().toISOString().split('T')[0],
      });
      clearSelectedPlayers();
      setIsCreating(false);
      setActiveTournament(tournament);
    }
  };

  // Generate tournament matches based on number of players
  const generateMatches = (tournamentPlayers: any[]) => {
    const matches = [];
    const playerIds = tournamentPlayers.map(p => p.id);
    
    // If odd number of players, add a bye (null)
    if (playerIds.length % 2 !== 0) {
      playerIds.push('bye');
    }
    
    // Create first round matches
    for (let i = 0; i < playerIds.length; i += 2) {
      matches.push({
        id: `match-${i/2 + 1}`,
        round: 1,
        playerIds: [playerIds[i], playerIds[i+1]] as [string, string],
        winnerId: null,
        scores: [0, 0] as [number, number],
      });
    }
    
    return matches;
  };

  // Record match result
  const recordMatchResult = (matchId: string, winnerId: string, scores: [number, number]) => {
    if (!activeTournament) return;
    
    const updatedTournament = { ...activeTournament };
    const matchIndex = updatedTournament.matches.findIndex(m => m.id === matchId);
    
    if (matchIndex !== -1) {
      updatedTournament.matches[matchIndex].winnerId = winnerId;
      updatedTournament.matches[matchIndex].scores = scores;
      
      // Check if tournament is complete
      const remainingMatches = updatedTournament.matches.filter(m => m.winnerId === null);
      if (remainingMatches.length === 0) {
        // Find the winner of the last match
        const finalMatch = updatedTournament.matches[updatedTournament.matches.length - 1];
        updatedTournament.winner = finalMatch.winnerId;
        updatedTournament.isComplete = true;
      }
      
      setActiveTournament(updatedTournament);
      setTournaments(tournaments.map(t => 
        t.id === updatedTournament.id ? updatedTournament : t
      ));
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Tournaments</h1>
        <button
          onClick={() => setIsCreating(!isCreating)}
          className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 flex items-center"
        >
          <Trophy size={18} className="mr-2" />
          <span>New Tournament</span>
        </button>
      </div>
      
      {/* Create Tournament Form */}
      {isCreating && (
        <div className="bg-white rounded-xl shadow-md p-6 mb-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-semibold text-lg">Create New Tournament</h2>
            <button 
              onClick={() => setIsCreating(false)}
              className="text-gray-400 hover:text-gray-600"
            >
              <X size={20} />
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Tournament Name
              </label>
              <input
                type="text"
                value={newTournament.name}
                onChange={(e) => setNewTournament({ ...newTournament, name: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                placeholder="E.g., Summer Championship"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Date
              </label>
              <input
                type="date"
                value={newTournament.date}
                onChange={(e) => setNewTournament({ ...newTournament, date: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
            </div>
          </div>
          
          <div className="mb-6">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-medium text-gray-700">Select Players</h3>
              <span className="text-sm text-gray-500">
                {selectedPlayers.length} selected
              </span>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
              {players.map(player => (
                <div
                  key={player.id}
                  onClick={() => selectedPlayers.find(p => p.id === player.id) 
                    ? deselectPlayer(player.id) 
                    : selectPlayer(player.id)
                  }
                  className={`flex items-center p-2 rounded-md cursor-pointer ${
                    selectedPlayers.find(p => p.id === player.id)
                      ? 'bg-emerald-100 border border-emerald-400'
                      : 'bg-gray-50 hover:bg-gray-100 border border-transparent'
                  }`}
                >
                  <img
                    src={player.avatar}
                    alt={player.name}
                    className="w-8 h-8 rounded-full mr-2"
                  />
                  <span className="text-sm truncate">{player.name}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div className="flex justify-end">
            <button
              onClick={createTournament}
              disabled={!newTournament.name || selectedPlayers.length < 2}
              className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 disabled:opacity-50"
            >
              Create Tournament
            </button>
          </div>
        </div>
      )}
      
      {/* Tournament List */}
      {!activeTournament && (
        <div className="bg-white rounded-xl shadow-md overflow-hidden mb-6">
          <div className="px-6 py-4 border-b">
            <h2 className="font-semibold text-gray-800">Your Tournaments</h2>
          </div>
          
          {tournaments.length > 0 ? (
            <div className="divide-y divide-gray-100">
              {tournaments.map((tournament) => (
                <div 
                  key={tournament.id}
                  onClick={() => setActiveTournament(tournament)}
                  className="px-6 py-4 hover:bg-gray-50 cursor-pointer"
                >
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 flex items-center justify-center bg-amber-100 rounded-full">
                        <Trophy size={24} className="text-amber-600" />
                      </div>
                    </div>
                    <div className="ml-4 flex-1">
                      <h3 className="font-medium text-gray-800">{tournament.name}</h3>
                      <div className="flex space-x-4 text-sm text-gray-500 mt-1">
                        <div className="flex items-center">
                          <Calendar size={14} className="mr-1" />
                          <span>{new Date(tournament.date).toLocaleDateString()}</span>
                        </div>
                        <div className="flex items-center">
                          <Users size={14} className="mr-1" />
                          <span>{tournament.players.length} players</span>
                        </div>
                      </div>
                    </div>
                    <div className="ml-4">
                      {tournament.isComplete ? (
                        <div className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                          Complete
                        </div>
                      ) : (
                        <div className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                          In Progress
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-6 text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                <Trophy size={32} className="text-gray-400" />
              </div>
              <p className="text-gray-500 mb-4">No tournaments found. Create one to get started!</p>
              <button
                onClick={() => setIsCreating(true)}
                className="inline-flex items-center px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700"
              >
                <Plus size={16} className="mr-2" />
                Create Tournament
              </button>
            </div>
          )}
        </div>
      )}
      
      {/* Active Tournament View */}
      {activeTournament && (
        <div>
          <div className="flex items-center mb-6">
            <button 
              onClick={() => setActiveTournament(null)}
              className="mr-4 p-2 rounded-full hover:bg-gray-100"
            >
              <ChevronLeft size={24} />
            </button>
            <div>
              <h2 className="text-xl font-bold text-gray-800">{activeTournament.name}</h2>
              <div className="flex space-x-4 text-sm text-gray-500">
                <div className="flex items-center">
                  <Calendar size={14} className="mr-1" />
                  <span>{new Date(activeTournament.date).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center">
                  <Users size={14} className="mr-1" />
                  <span>{activeTournament.players.length} players</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Tournament Brackets */}
          <div className="bg-white rounded-xl shadow-md p-6 mb-6">
            <h3 className="font-semibold text-gray-800 mb-4">Tournament Bracket</h3>
            
            <div className="overflow-x-auto">
              <div className="min-w-[600px] p-4">
                {/* Simple bracket representation */}
                {activeTournament.matches.map((match, index) => {
                  const player1 = activeTournament.players.find(p => p.id === match.playerIds[0]);
                  const player2 = activeTournament.players.find(p => p.id === match.playerIds[1]);
                  const isComplete = match.winnerId !== null;
                  
                  return (
                    <div key={match.id} className="mb-4 p-4 border rounded-lg bg-gray-50">
                      <div className="flex justify-between items-center mb-2">
                        <div className="font-medium">Match {index + 1}</div>
                        <div className="text-sm text-gray-500">Round {match.round}</div>
                      </div>
                      
                      <div className={`flex items-center justify-between p-2 rounded-md ${
                        match.winnerId === match.playerIds[0] ? 'bg-green-100' : 'bg-white'
                      }`}>
                        <div className="flex items-center">
                          {player1 ? (
                            <>
                              <img 
                                src={player1.avatar} 
                                alt={player1.name}
                                className="w-8 h-8 rounded-full mr-2"
                              />
                              <span>{player1.name}</span>
                            </>
                          ) : (
                            <span className="text-gray-400">Bye</span>
                          )}
                        </div>
                        <div className="font-bold">{match.scores[0]}</div>
                      </div>
                      
                      <div className="text-center text-xs text-gray-500 my-1">vs</div>
                      
                      <div className={`flex items-center justify-between p-2 rounded-md ${
                        match.winnerId === match.playerIds[1] ? 'bg-green-100' : 'bg-white'
                      }`}>
                        <div className="flex items-center">
                          {player2 ? (
                            <>
                              <img 
                                src={player2.avatar} 
                                alt={player2.name}
                                className="w-8 h-8 rounded-full mr-2" 
                              />
                              <span>{player2.name}</span>
                            </>
                          ) : (
                            <span className="text-gray-400">Bye</span>
                          )}
                        </div>
                        <div className="font-bold">{match.scores[1]}</div>
                      </div>
                      
                      {!isComplete && player1 && player2 && (
                        <div className="mt-3 text-center">
                          <button className="px-3 py-1 bg-blue-600 text-white rounded-md text-sm">
                            Record Result
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
          
          {/* Tournament Players */}
          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="font-semibold text-gray-800 mb-4">Tournament Players</h3>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {activeTournament.players.map((player) => {
                const isWinner = activeTournament.winner === player.id;
                
                return (
                  <div 
                    key={player.id}
                    className={`bg-white rounded-lg border p-4 text-center ${
                      isWinner ? 'border-amber-400 shadow-md' : 'border-gray-200'
                    }`}
                  >
                    <div className="relative">
                      <img 
                        src={player.avatar} 
                        alt={player.name}
                        className="w-16 h-16 rounded-full mx-auto mb-2 object-cover" 
                      />
                      {isWinner && (
                        <div className="absolute -top-2 -right-2 bg-amber-400 rounded-full p-1">
                          <Trophy size={16} className="text-white" />
                        </div>
                      )}
                    </div>
                    <div className="font-medium">{player.name}</div>
                    {isWinner && (
                      <div className="text-xs text-amber-600 mt-1">Winner</div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const ChevronLeft = ({ size = 24, ...props }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round"
    {...props}
  >
    <path d="m15 18-6-6 6-6"/>
  </svg>
);

export default TournamentPage;