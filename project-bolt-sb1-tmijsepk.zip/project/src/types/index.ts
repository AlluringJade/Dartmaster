// Player related types
export interface PlayerStats {
  gamesPlayed: number;
  gamesWon: number;
  averageScore: number;
  highestScore: number;
  tournaments: {
    id: string;
    name: string;
    position: number;
    date: string;
  }[];
}

export interface Player {
  id: string;
  name: string;
  avatar: string;
  stats: PlayerStats;
}

// Game related types
export type GameType = '501' | 'cricket' | 'around-the-clock' | null;

export interface ScoreHistory {
  playerId: string;
  score: number;
  roundNumber: number;
  timestamp: string;
}

export interface GameState {
  gameType: GameType;
  players: Player[];
  currentPlayerIndex: number;
  scores: Record<string, number>;
  history: ScoreHistory[];
  isGameActive: boolean;
  winner: string | null;
  roundNumber: number;
}

export type GameAction =
  | { type: 'START_GAME'; payload: { gameType: GameType; players: Player[] } }
  | { type: 'RECORD_SCORE'; payload: { playerId: string; score: number } }
  | { type: 'NEXT_PLAYER' }
  | { type: 'END_GAME'; payload: { winnerId: string } }
  | { type: 'RESET_GAME' };

// Tournament related types
export interface Tournament {
  id: string;
  name: string;
  date: string;
  players: Player[];
  matches: TournamentMatch[];
  winner: string | null;
  isComplete: boolean;
}

export interface TournamentMatch {
  id: string;
  round: number;
  playerIds: [string, string];
  winnerId: string | null;
  scores: [number, number];
}