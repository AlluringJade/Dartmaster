import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { GameProvider } from './contexts/GameContext';
import { PlayerProvider } from './contexts/PlayerContext';
import Layout from './components/Layout';
import HomePage from './pages/HomePage';
import GamePage from './pages/GamePage';
import TournamentPage from './pages/TournamentPage';
import ProfilePage from './pages/ProfilePage';
import StatsPage from './pages/StatsPage';

function App() {
  return (
    <Router>
      <PlayerProvider>
        <GameProvider>
          <Layout>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/game/:gameType" element={<GamePage />} />
              <Route path="/tournament" element={<TournamentPage />} />
              <Route path="/profile" element={<ProfilePage />} />
              <Route path="/stats" element={<StatsPage />} />
            </Routes>
          </Layout>
        </GameProvider>
      </PlayerProvider>
    </Router>
  );
}

export default App;