import React, { useState, useEffect } from 'react';
import { useGame } from '../../contexts/GameContext';
import { GameType } from '../../types';
import { Camera, Target, CheckCircle, XCircle } from 'lucide-react';

interface ScoreInputProps {
  gameType: GameType;
  isUsingCamera: boolean;
  onScoreSubmit: (score: number) => void;
}

const ScoreInput: React.FC<ScoreInputProps> = ({ gameType, isUsingCamera, onScoreSubmit }) => {
  const { state } = useGame();
  const [score, setScore] = useState<number>(0);
  const [throws, setThrows] = useState<number[]>([0, 0, 0]);
  const [currentThrow, setCurrentThrow] = useState<number>(0);
  const [cameraFeedback, setCameraFeedback] = useState<string | null>(null);

  const currentPlayer = state.players[state.currentPlayerIndex];

  // Calculate remaining score for 501 game
  const remainingScore = gameType === '501' ? state.scores[currentPlayer.id] : null;

  // Reset throws when player changes
  useEffect(() => {
    setScore(0);
    setThrows([0, 0, 0]);
    setCurrentThrow(0);
    setCameraFeedback(null);
  }, [state.currentPlayerIndex]);

  // Handle number pad input
  const handleNumberInput = (num: number) => {
    if (currentThrow < 3) {
      const newThrows = [...throws];
      newThrows[currentThrow] = num;
      setThrows(newThrows);
      setScore(newThrows.reduce((sum, val) => sum + val, 0));
      setCurrentThrow(currentThrow + 1);
    }
  };

  // Handle dart multipliers (double, triple)
  const applyMultiplier = (multiplier: number) => {
    if (currentThrow > 0 && currentThrow <= 3) {
      const newThrows = [...throws];
      newThrows[currentThrow - 1] = newThrows[currentThrow - 1] * multiplier;
      setThrows(newThrows);
      setScore(newThrows.reduce((sum, val) => sum + val, 0));
    }
  };

  // Simulate camera detection
  const simulateCameraDetection = () => {
    setCameraFeedback("Detecting throw...");
    setTimeout(() => {
      const randomScore = Math.floor(Math.random() * 20) + 1;
      const multiplier = Math.random() > 0.7 ? (Math.random() > 0.5 ? 2 : 3) : 1;
      const detectedScore = randomScore * multiplier;
      
      const newThrows = [...throws];
      newThrows[currentThrow] = detectedScore;
      setThrows(newThrows);
      setScore(newThrows.reduce((sum, val) => sum + val, 0));
      setCurrentThrow(currentThrow + 1);
      
      setCameraFeedback(`Detected: ${detectedScore} (${multiplier}x${randomScore})`);
    }, 1000);
  };

  // Reset current round
  const resetRound = () => {
    setScore(0);
    setThrows([0, 0, 0]);
    setCurrentThrow(0);
    setCameraFeedback(null);
  };

  // Submit score
  const submitScore = () => {
    onScoreSubmit(score);
    setScore(0);
    setThrows([0, 0, 0]);
    setCurrentThrow(0);
    setCameraFeedback(null);
  };

  // Check if score is valid for 501 (can't bust)
  const isScoreValid = () => {
    if (gameType !== '501') return true;
    
    const newScore = remainingScore! - score;
    return newScore >= 0 && (newScore === 0 || newScore >= 2);
  };

  if (isUsingCamera) {
    return (
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="mb-4">
          <h2 className="text-lg font-semibold text-gray-800 mb-2">Camera Scoring</h2>
          <p className="text-sm text-gray-600">Point your camera at the dartboard to auto-detect scores.</p>
        </div>
        
        <div className="mb-6 aspect-video bg-gray-100 rounded-lg flex items-center justify-center relative">
          <Camera size={48} className="text-gray-400" />
          {cameraFeedback && (
            <div className="absolute bottom-0 left-0 right-0 bg-black/70 text-white p-2 text-center">
              {cameraFeedback}
            </div>
          )}
        </div>
        
        <div className="mb-4">
          <div className="grid grid-cols-3 gap-2 text-center text-lg">
            {throws.map((t, i) => (
              <div 
                key={i} 
                className={`rounded-md py-2 ${
                  i === currentThrow 
                    ? 'bg-purple-100 text-purple-700 font-medium' 
                    : 'bg-gray-50 text-gray-700'
                }`}
              >
                {t > 0 ? t : '-'}
              </div>
            ))}
          </div>
          <div className="text-center mt-2 text-lg font-bold">
            Total: {score}
          </div>
        </div>
        
        <div className="flex space-x-2">
          <button 
            onClick={simulateCameraDetection}
            disabled={currentThrow >= 3}
            className="flex-1 py-3 rounded-md bg-purple-600 text-white font-medium disabled:opacity-50"
          >
            Detect Throw
          </button>
          <button 
            onClick={resetRound}
            className="py-3 px-4 rounded-md bg-gray-100 text-gray-700 hover:bg-gray-200"
          >
            <XCircle size={20} />
          </button>
          <button 
            onClick={submitScore}
            disabled={currentThrow === 0 || !isScoreValid()}
            className="py-3 px-4 rounded-md bg-emerald-600 text-white hover:bg-emerald-700 disabled:opacity-50"
          >
            <CheckCircle size={20} />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-md p-6">
      <div className="mb-4">
        <h2 className="text-lg font-semibold text-gray-800">
          {currentPlayer.name}'s Turn
        </h2>
        {remainingScore !== null && (
          <p className="text-sm text-gray-600">
            Remaining: <span className="font-medium">{remainingScore}</span>
          </p>
        )}
      </div>
      
      <div className="mb-4">
        <div className="grid grid-cols-3 gap-2 text-center text-lg">
          {throws.map((t, i) => (
            <div 
              key={i} 
              className={`rounded-md py-2 ${
                i === currentThrow 
                  ? 'bg-blue-100 text-blue-700 font-medium' 
                  : 'bg-gray-50 text-gray-700'
              }`}
            >
              {t > 0 ? t : '-'}
            </div>
          ))}
        </div>
        <div className="text-center mt-2 text-lg font-bold">
          Total: {score}
        </div>
      </div>
      
      <div className="mb-4">
        <div className="grid grid-cols-3 gap-2">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
            <button
              key={num}
              onClick={() => handleNumberInput(num)}
              disabled={currentThrow >= 3}
              className="p-3 rounded-md bg-gray-50 text-gray-800 hover:bg-gray-100 disabled:opacity-50"
            >
              {num}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-3 gap-2 mt-2">
          {[10, 11, 12, 13, 14, 15, 16, 17, 18].map((num) => (
            <button
              key={num}
              onClick={() => handleNumberInput(num)}
              disabled={currentThrow >= 3}
              className="p-3 rounded-md bg-gray-50 text-gray-800 hover:bg-gray-100 disabled:opacity-50"
            >
              {num}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-3 gap-2 mt-2">
          <button
            onClick={() => handleNumberInput(19)}
            disabled={currentThrow >= 3}
            className="p-3 rounded-md bg-gray-50 text-gray-800 hover:bg-gray-100 disabled:opacity-50"
          >
            19
          </button>
          <button
            onClick={() => handleNumberInput(20)}
            disabled={currentThrow >= 3}
            className="p-3 rounded-md bg-gray-50 text-gray-800 hover:bg-gray-100 disabled:opacity-50"
          >
            20
          </button>
          <button
            onClick={() => handleNumberInput(25)}
            disabled={currentThrow >= 3}
            className="p-3 rounded-md bg-gray-50 text-gray-800 hover:bg-gray-100 disabled:opacity-50"
          >
            Bull
          </button>
        </div>
      </div>
      
      <div className="flex space-x-2 mb-4">
        <button
          onClick={() => handleNumberInput(0)}
          disabled={currentThrow >= 3}
          className="flex-1 py-2 rounded-md bg-gray-200 text-gray-800 font-medium disabled:opacity-50"
        >
          Miss
        </button>
        <button
          onClick={() => applyMultiplier(2)}
          disabled={currentThrow === 0 || currentThrow > 3}
          className="flex-1 py-2 rounded-md bg-green-100 text-green-800 font-medium disabled:opacity-50"
        >
          Double
        </button>
        <button
          onClick={() => applyMultiplier(3)}
          disabled={currentThrow === 0 || currentThrow > 3}
          className="flex-1 py-2 rounded-md bg-blue-100 text-blue-800 font-medium disabled:opacity-50"
        >
          Triple
        </button>
      </div>
      
      <div className="flex space-x-2">
        <button 
          onClick={resetRound}
          className="flex-1 py-3 rounded-md bg-gray-100 text-gray-700 hover:bg-gray-200"
        >
          Reset
        </button>
        <button 
          onClick={submitScore}
          disabled={currentThrow === 0 || !isScoreValid()}
          className={`flex-1 py-3 rounded-md font-medium ${
            isScoreValid() 
              ? 'bg-emerald-600 text-white hover:bg-emerald-700' 
              : 'bg-red-100 text-red-700'
          } disabled:opacity-50`}
        >
          {isScoreValid() ? 'Submit' : 'Invalid Score'}
        </button>
      </div>
    </div>
  );
};

export default ScoreInput;