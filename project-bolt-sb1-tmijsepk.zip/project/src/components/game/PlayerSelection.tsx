import React, { useState } from 'react';
import { UserPlus, Users, Monitor } from 'lucide-react';
import { usePlayers } from '../../contexts/PlayerContext';

interface PlayerSelectionProps {
  onStartGame: () => void;
}

const PlayerSelection: React.FC<PlayerSelectionProps> = ({ onStartGame }) => {
  const { players, selectedPlayers, selectPlayer, deselectPlayer } = usePlayers();
  const [showAddPlayer, setShowAddPlayer] = useState(false);
  const [newPlayer, setNewPlayer] = useState({ name: '', avatar: 'https://i.pravatar.cc/150?img=3' });

  const isPlayerSelected = (id: string) => {
    return selectedPlayers.some(player => player.id === id);
  };

  const togglePlayerSelection = (id: string) => {
    if (isPlayerSelected(id)) {
      deselectPlayer(id);
    } else {
      selectPlayer(id);
    }
  };

  const handleAddPlayer = () => {
    // We're using the PlayerContext in the parent so we don't need to directly
    // add the player here, just clearing the form
    setNewPlayer({ name: '', avatar: 'https://i.pravatar.cc/150?img=3' });
    setShowAddPlayer(false);
  };

  // Add computer player
  const addComputerPlayer = () => {
    const computerPlayer = {
      id: 'computer',
      name: 'Computer',
      avatar: 'https://i.pravatar.cc/150?img=8',
      stats: {
        gamesPlayed: 0,
        gamesWon: 0,
        averageScore: 0,
        highestScore: 0,
        tournaments: [],
      },
    };
    
    selectPlayer(computerPlayer.id);
  };
  
  return (
    <div>
      <div className="bg-white rounded-xl shadow-md overflow-hidden mb-6">
        <div className="px-6 py-4 border-b">
          <h2 className="font-semibold text-gray-800">Select Players</h2>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mb-6">
            {players.map(player => (
              <button
                key={player.id}
                onClick={() => togglePlayerSelection(player.id)}
                className={`p-4 rounded-lg text-center transition-all ${
                  isPlayerSelected(player.id)
                    ? 'bg-emerald-100 border-2 border-emerald-500'
                    : 'bg-gray-50 border-2 border-transparent hover:border-gray-200'
                }`}
              >
                <img
                  src={player.avatar}
                  alt={player.name}
                  className="w-16 h-16 object-cover rounded-full mx-auto mb-2"
                />
                <div className="font-medium text-gray-800">{player.name}</div>
                <div className="text-xs text-gray-500">
                  {player.stats.gamesPlayed} games
                </div>
              </button>
            ))}
            
            <button
              onClick={() => setShowAddPlayer(true)}
              className="p-4 rounded-lg bg-gray-50 text-center hover:bg-gray-100 border-2 border-dashed border-gray-300"
            >
              <div className="w-16 h-16 mx-auto mb-2 rounded-full bg-gray-100 flex items-center justify-center">
                <UserPlus size={24} className="text-gray-400" />
              </div>
              <div className="font-medium text-gray-600">Add Player</div>
            </button>
            
            <button
              onClick={addComputerPlayer}
              className="p-4 rounded-lg bg-blue-50 text-center hover:bg-blue-100 border-2 border-dashed border-blue-200"
            >
              <div className="w-16 h-16 mx-auto mb-2 rounded-full bg-blue-100 flex items-center justify-center">
                <Monitor size={24} className="text-blue-500" />
              </div>
              <div className="font-medium text-blue-600">Computer</div>
            </button>
          </div>
          
          {showAddPlayer && (
            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <h3 className="font-medium text-gray-800 mb-3">Add New Player</h3>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Name
                </label>
                <input
                  type="text"
                  value={newPlayer.name}
                  onChange={(e) => setNewPlayer({ ...newPlayer, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  placeholder="Enter player name"
                />
              </div>
              <div className="flex justify-end space-x-2">
                <button
                  onClick={() => setShowAddPlayer(false)}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddPlayer}
                  disabled={!newPlayer.name.trim()}
                  className="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 disabled:opacity-50"
                >
                  Add Player
                </button>
              </div>
            </div>
          )}
          
          <div className="mt-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-gray-800">Selected Players</h3>
              <span className="text-sm text-gray-500">
                {selectedPlayers.length} player(s)
              </span>
            </div>
            
            {selectedPlayers.length > 0 ? (
              <div className="bg-gray-50 p-4 rounded-lg">
                {selectedPlayers.map(player => (
                  <div key={player.id} className="flex items-center justify-between py-2">
                    <div className="flex items-center">
                      <img
                        src={player.avatar}
                        alt={player.name}
                        className="w-8 h-8 rounded-full mr-3"
                      />
                      <span className="text-gray-800">{player.name}</span>
                    </div>
                    <button
                      onClick={() => deselectPlayer(player.id)}
                      className="text-gray-400 hover:text-red-500"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-gray-50 p-4 rounded-lg text-center">
                <Users size={24} className="mx-auto mb-2 text-gray-400" />
                <p className="text-gray-500">No players selected</p>
              </div>
            )}
          </div>
        </div>
      </div>
      
      <div className="flex justify-end">
        <button
          onClick={onStartGame}
          disabled={selectedPlayers.length === 0}
          className="px-6 py-3 bg-emerald-600 text-white font-medium rounded-lg shadow-md hover:bg-emerald-700 transition-colors disabled:opacity-50"
        >
          Start Game
        </button>
      </div>
    </div>
  );
};

export default PlayerSelection;