import React from 'react';
import { useGame } from '../../contexts/GameContext';

const GameScoreboard: React.FC = () => {
  const { state } = useGame();
  const { players, scores, currentPlayerIndex, gameType, roundNumber } = state;

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden">
      <div className="bg-gray-50 px-6 py-4 border-b">
        <div className="flex justify-between items-center">
          <h2 className="font-semibold text-gray-800">Scoreboard</h2>
          <div className="text-sm text-gray-500">Round {roundNumber}</div>
        </div>
      </div>
      
      <div className="divide-y divide-gray-100">
        {players.map((player, index) => {
          const isCurrentPlayer = index === currentPlayerIndex;
          const playerScore = scores[player.id];
          
          return (
            <div 
              key={player.id}
              className={`px-6 py-4 flex items-center ${
                isCurrentPlayer ? 'bg-emerald-50' : ''
              }`}
            >
              <div className="flex-shrink-0 relative">
                <img 
                  src={player.avatar} 
                  alt={player.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-gray-200" 
                />
                {isCurrentPlayer && (
                  <div className="absolute -right-1 -top-1 w-5 h-5 bg-emerald-500 rounded-full flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                  </div>
                )}
              </div>
              
              <div className="ml-4 flex-1">
                <div className="font-medium text-gray-800">{player.name}</div>
                <div className="text-sm text-gray-500">
                  {isCurrentPlayer ? 'Current turn' : ''}
                </div>
              </div>
              
              <div className={`text-2xl font-bold ${
                gameType === '501' 
                  ? 'text-blue-600' 
                  : 'text-emerald-600'
              }`}>
                {playerScore}
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Score history */}
      {state.history.length > 0 && (
        <div className="border-t border-gray-100 px-6 py-4">
          <h3 className="text-sm font-medium text-gray-500 mb-2">Recent Scores</h3>
          <div className="text-sm">
            {state.history.slice(-3).reverse().map((entry, i) => {
              const player = players.find(p => p.id === entry.playerId);
              return (
                <div key={i} className="flex items-center py-1">
                  <span className="font-medium text-gray-700 mr-2">{player?.name}:</span>
                  <span className="text-gray-600">
                    {gameType === '501' ? '-' : '+'}{entry.score} points
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default GameScoreboard;